import React, { useState } from "react";

import Card from "../UI/Card";
import Button from "../UI/Button";
import classes from "./AddUsers.module.css";
import ErrorModal from "../UI/ErrorModal";

const AddUsers = (props) => {
  const [userName, setUsername] = useState("");
  const [age, setAge] = useState("");
  const [error, setError] = useState();

  const onUserAdded = (event) => {
    event.preventDefault();
    //console.log('userName ... ' + userName + ' ... age ... ' + age);
    if (age.trim().length === 0) {
      setError({
        title: "Invalid input",
        message: "Please enter a valid name.",
      });
      return;
    }
    if (userName.trim().length === 0 || +age < 1) {
      setError({
        title: "Invalid age",
        message: "Please enter a valid age.",
      });
      return;
    }
    console.log("userName ... " + userName + " ... age ... " + age);
    const addedUser = {
      userName: userName,
      age: age,
      id: Math.random().toString(),
    };
    props.onUserAdded(addedUser);
    setAge("");
    setUsername("");
  };

  const userNameHandler = (event) => {
    setUsername(event.target.value);
    //console.log(event.target.value);
  };

  const ageHandler = (event) => {
    setAge(event.target.value);
    //console.log(event.target.value);
  };

  const resetErrorHandler = () => {
      setError(null);
  }

  return (
    <div>
      {error && (
        <ErrorModal title={error.title} message={error.message} onConfirm={resetErrorHandler}></ErrorModal>
      )}
      <Card className={classes.input}>
        <form onSubmit={onUserAdded}>
          <label htmlFor="username">UserName</label>
          <input
            id="username"
            type="text"
            value={userName}
            onChange={userNameHandler}
          ></input>
          <label htmlFor="age">Age</label>
          <input
            id="age"
            type="number"
            value={age}
            onChange={ageHandler}
          ></input>
          <Button type="submit">Add User</Button>
        </form>
      </Card>
    </div>
  );
};

export default AddUsers;
