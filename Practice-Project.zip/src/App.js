import React, { useState } from "react";

import AddUser from "./Components/Users/AddUsers";
import UsersList from "./Components/Users/UsersList";

function App() {
  const [usersList, setUsersList] = useState([]);

  const addUserHandler = (newUser) => {
    setUsersList((prevUsers) => {
      return [newUser, ...prevUsers];
    });
  };

  return (
    <div>
      <AddUser onUserAdded={addUserHandler} />
      {usersList.length && <UsersList usersData={usersList} />}
    </div>
  );
}

export default App;
